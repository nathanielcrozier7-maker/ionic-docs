import React from 'react';
import { CosmicButton, CosmicCard, CosmicNavbar } from 'cosmic-ui-lite';
import './App.css';

function App() {
  return (
    <div className="app">
      <CosmicNavbar
        items={[
          { icon: '🏠', label: 'Home' },
          { icon: '🎰', label: 'Games' },
          { icon: '💰', label: 'Wallet' },
          { icon: '🛠️', label: 'Support' }
        ]}
      />

      <div className="wallet-display">
        <CosmicCard title="Wallet Balance" content="₿ 0.042 BTC" />
      </div>

      <div className="slot-machine">
        <CosmicCard title="Alien Slot Machine">
          <div className="slot-reels">
            👽 🛸 🌌
          </div>
          <CosmicButton text="Spin" variant="primary" onClick={() => alert('Spinning!')} />
        </CosmicCard>
      </div>

      <div className="actions">
        <CosmicButton text="Deposit" variant="success" />
        <CosmicButton text="Withdraw" variant="danger" />
      </div>
    </div>
  );
}

export default App;

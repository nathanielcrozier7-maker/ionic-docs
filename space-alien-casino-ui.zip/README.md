# Space Alien Casino UI

This is a React-based UI for the Space Alien Casino game using Cosmic UI Lite components.

## Setup

1. Install dependencies:
   npm install cosmic-ui-lite

2. Add Orbitron font in index.html:
   <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@500&display=swap" rel="stylesheet">

3. Run the app:
   npm start
